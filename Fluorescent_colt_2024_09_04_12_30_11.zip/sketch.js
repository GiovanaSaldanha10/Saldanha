var a =10;

function setup() {
  createCanvas(400, 400);
  }

function draw(){ 
  //background ("blue");
  
  if (mousIsPressed) {
    fill(0);
  } else {
    fill(255);
  }
  ellipse(mousex, mousey,80,80);
}